
import React, { Component } from 'react'
import style from './style.less'


class UserMain extends Component {
  constructor(props, context) {
    super(props, context)
  }

  renderUsers() {
    return this.props.users.map((obj) => {
          <tr>
            <td>{obj.id}</td>
            <td>{obj.firstName}</td>
            <td>{obj.lastName}</td>
            <td>{obj.email}</td>
            <td>{obj.phone}</td>
            <td>{obj.address}</td>
          </tr>
    });
  }

  render() {
    var sHeight = {height: 100};

    var mapUsers = this.renderUsers();

    return (
        <main>
          <div className="nav-wrapper cyan" style={sHeight}>
            <div className="row">
              <div className="col s12 offset-s1" style={{marginTop: 75, position: 'absolute'}}>
                <a className="btn-floating btn-large waves-effect waves-light red"><i className="material-icons">add</i></a>
              </div>
            </div>
          </div>
          <div className="container">
            <div className="row">
              <div className="col s12">
                <table className="bordered striped centered responsive-table" style={{marginTop: -48}}>
                  <thead style={{color: '#fff', backgroundColor: '#00d4ef'}}>
                  <tr>
                    <th data-field="id">ID</th>
                    <th data-field="firstName">First name</th>
                    <th data-field="lastName">Last name</th>
                    <th data-field="email">Email</th>
                    <th data-field="phone">Phone</th>
                    <th data-field="address">Address</th>
                  </tr>
                  </thead>
                  <tbody className="dataTable">
                    {mapUsers}
                  </tbody>
                </table>

              </div>
            </div>
          </div>
        </main>
    )
  }
}

export default UserMain
