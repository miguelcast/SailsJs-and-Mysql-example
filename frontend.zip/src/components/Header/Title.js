import React, { Component } from 'react'

class Title extends Component {
  render() {
    return (
        <nav className="z-depth-0 cyan">
            <div className="nav-wrapper">
                <a href="#" className="brand-logo center">Users</a>
            </div>
        </nav>
    )
  }
}

export default Title
