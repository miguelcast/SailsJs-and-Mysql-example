
import { createAction } from 'redux-actions'

export const getUsers = createAction('GET_USERS')