import React, { Component, PropTypes } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Title from '../../components/Header/Title'
import UserMain from '../../components/UserMain'
import * as UsersActions from '../../actions/users'

class User extends Component {
  render() {
    const {users, actions, children } = this.props
    return (
      <div>
        <Title title="Users" />
        <UserMain users={users} actions={actions} />
        {children}
      </div>
    )
  }
}
User.propTypes = {
  users: PropTypes.array,
  actions: PropTypes.object,
  children: PropTypes.node
}

function mapStateToProps(state) {
    return {
        users: state.users
    }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(UsersActions, dispatch)
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(User)
