
import { handleActions } from 'redux-actions'

const initialState = [{
  users: []
}]

export default handleActions({
  'GET_USERS' (state, action) {
    return [{
      users: action.payload
    }, ...state]
  }
}, initialState)
