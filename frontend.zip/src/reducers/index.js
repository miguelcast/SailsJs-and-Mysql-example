
import { routerReducer as routing } from 'react-router-redux'
import { combineReducers } from 'redux'
import todos from './todos'
import users from './users'

export default combineReducers({
  routing,
  todos,
  users
})
